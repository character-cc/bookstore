import { type RouteConfig, index } from "@react-router/dev/routes";
import {layout , route} from "@react-router/dev/routes";

export default [
    index("routes/home.tsx"),


    layout("./components/auth/auth-layout.tsx", [
        route("login", "./components/auth/login.tsx"),
        route("register", "./components/auth/register.tsx"),
    ]),
    route("/admin/dashboard", "./components/admin/dashboard.tsx"),

] satisfies RouteConfig;
