"use client"

import type React from "react"

import { ChevronDown, Heart, Menu, Search, ShoppingCart, User } from "lucide-react"
import { Link } from "react-router"
import { useState } from "react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function EcommerceHeader() {
    const [searchQuery, setSearchQuery] = useState("")

    // Dữ liệu mẫu cho danh mục
    const categories = [
        {
            name: "Thời trang",
            subcategories: [
                { name: "Áo nam", href: "/ao-nam" },
                { name: "Áo nữ", href: "/ao-nu" },
                { name: "Quần jean", href: "/quan-jean" },
                { name: "Giày dép", href: "/giay-dep" },
                { name: "Phụ kiện", href: "/phu-kien" },
            ],
        },
        {
            name: "Điện tử",
            subcategories: [
                { name: "Điện thoại", href: "/dien-thoai" },
                { name: "Laptop", href: "/laptop" },
                { name: "Tai nghe", href: "/tai-nghe" },
                { name: "Đồng hồ thông minh", href: "/dong-ho-thong-minh" },
            ],
        },
        {
            name: "Gia dụng",
            subcategories: [
                { name: "Nội thất", href: "/noi-that" },
                { name: "Đồ bếp", href: "/do-bep" },
                { name: "Đèn trang trí", href: "/den-trang-tri" },
                { name: "Đồ dùng phòng tắm", href: "/do-dung-phong-tam" },
            ],
        },
        {
            name: "Sách & Văn phòng phẩm",
            subcategories: [
                { name: "Sách giáo khoa", href: "/sach-giao-khoa" },
                { name: "Tiểu thuyết", href: "/tieu-thuyet" },
                { name: "Văn phòng phẩm", href: "/van-phong-pham" },
                { name: "Đồ chơi giáo dục", href: "/do-choi-giao-duc" },
            ],
        },
        {
            name: "Thể thao",
            subcategories: [
                { name: "Quần áo thể thao", href: "/quan-ao-the-thao" },
                { name: "Giày thể thao", href: "/giay-the-thao" },
                { name: "Dụng cụ tập gym", href: "/dung-cu-tap-gym" },
                { name: "Đồ bơi", href: "/do-boi" },
            ],
        },
    ]

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault()
        console.log("Tìm kiếm:", searchQuery)
        // Xử lý tìm kiếm ở đây
    }

    return (
        <header className="w-full border-b bg-white">
            {/* Hàng đầu - Logo, Search, Actions */}
            <div className="container mx-auto px-4">
                <div className="flex h-16 items-center justify-between gap-4">
                    {/* Logo */}
                    <Link to="/" className="flex items-center space-x-2">
                        <div className="h-8 w-8 rounded bg-primary flex items-center justify-center">
                            <span className="text-white font-bold text-lg">E</span>
                        </div>
                        <span className="hidden sm:block text-xl font-bold text-gray-900">EShop</span>
                    </Link>

                    {/* Thanh tìm kiếm */}
                    <form onSubmit={handleSearch} className="flex-1 max-w-2xl mx-4">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                            <Input
                                type="search"
                                placeholder="Tìm kiếm sản phẩm..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="w-full pl-10 pr-4"
                            />
                        </div>
                    </form>

                    {/* Actions - Wishlist, Cart, User */}
                    <div className="flex items-center space-x-2">
                        {/* Wishlist */}
                        <Button variant="ghost" size="icon" className="relative">
                            <Heart className="h-5 w-5" />
                            <Badge
                                variant="destructive"
                                className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
                            >
                                3
                            </Badge>
                            <span className="sr-only">Danh sách yêu thích</span>
                        </Button>

                        {/* Cart */}
                        <Button variant="ghost" size="icon" className="relative">
                            <ShoppingCart className="h-5 w-5" />
                            <Badge
                                variant="destructive"
                                className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
                            >
                                5
                            </Badge>
                            <span className="sr-only">Giỏ hàng</span>
                        </Button>

                        {/* User Menu */}
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                    <User className="h-5 w-5" />
                                    <span className="sr-only">Tài khoản</span>
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-56">
                                <DropdownMenuLabel>Tài khoản của tôi</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem asChild>
                                    <Link to="/profile" className="w-full cursor-pointer">
                                        Thông tin cá nhân
                                    </Link>
                                </DropdownMenuItem>
                                <DropdownMenuItem asChild>
                                    <Link to="/orders" className="w-full cursor-pointer">
                                        Đơn hàng của tôi
                                    </Link>
                                </DropdownMenuItem>
                                <DropdownMenuItem asChild>
                                    <Link to="/wishlist" className="w-full cursor-pointer">
                                        Danh sách yêu thích
                                    </Link>
                                </DropdownMenuItem>
                                <DropdownMenuItem asChild>
                                    <Link to="/settings" className="w-full cursor-pointer">
                                        Cài đặt
                                    </Link>
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-red-600 cursor-pointer">Đăng xuất</DropdownMenuItem>
                            </DropdownMenuContent>
                        </DropdownMenu>

                        {/* Mobile Menu */}
                        <Sheet>
                            <SheetTrigger asChild>
                                <Button variant="ghost" size="icon" className="lg:hidden">
                                    <Menu className="h-5 w-5" />
                                    <span className="sr-only">Menu</span>
                                </Button>
                            </SheetTrigger>
                            <SheetContent side="left" className="w-80">
                                <div className="flex flex-col space-y-4 mt-4">
                                    <h2 className="text-lg font-semibold">Danh mục sản phẩm</h2>
                                    {categories.map((category) => (
                                        <div key={category.name} className="space-y-2">
                                            <h3 className="font-medium text-gray-900">{category.name}</h3>
                                            <div className="pl-4 space-y-1">
                                                {category.subcategories.map((sub) => (
                                                    <Link
                                                        key={sub.name}
                                                        to={sub.href}
                                                        className="block text-sm text-gray-600 hover:text-gray-900"
                                                    >
                                                        {sub.name}
                                                    </Link>
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </SheetContent>
                        </Sheet>
                    </div>
                </div>
            </div>

            {/* Hàng thứ hai - Category Menu với DropdownMenu */}
            <div className="hidden lg:block border-t bg-gray-50">
                <div className="container mx-auto px-4">
                    <div className="flex items-center space-x-1">
                        {categories.map((category) => (
                            <DropdownMenu key={category.name}>
                                <DropdownMenuTrigger asChild>
                                    <Button
                                        variant="ghost"
                                        className="h-12 px-4 text-sm font-medium hover:bg-gray-100 data-[state=open]:bg-gray-100"
                                    >
                                        {category.name}
                                        <ChevronDown className="ml-1 h-3 w-3" />
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="start" className="w-64 p-2" sideOffset={0}>
                                    <div className="grid grid-cols-1 gap-1">
                                        {category.subcategories.map((subcategory) => (
                                            <DropdownMenuItem key={subcategory.name} asChild>
                                                <Link
                                                    to={subcategory.href}
                                                    className="w-full cursor-pointer rounded-sm px-3 py-2 text-sm hover:bg-accent hover:text-accent-foreground"
                                                >
                                                    {subcategory.name}
                                                </Link>
                                            </DropdownMenuItem>
                                        ))}
                                    </div>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        ))}

                        {/* Danh mục đặc biệt */}
                        <Button variant="ghost" asChild className="h-12 px-4 text-sm font-medium hover:bg-gray-100">
                            <Link to="/sale" className="text-red-600 font-semibold">
                                🔥 Sale
                            </Link>
                        </Button>
                    </div>
                </div>
            </div>
        </header>
    )
}
