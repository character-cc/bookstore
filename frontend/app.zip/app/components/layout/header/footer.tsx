"use client"

import { Facebook, Instagram, Mail, MapPin, Phone, Twitter, Youtube } from "lucide-react"
import {Link} from "react-router"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"

export default function Footer() {
    const bookCategories = [
        { name: "Văn học", to: "/van-hoc" },
        { name: "Kinh tế", to: "/kinh-te" },
        { name: "Kỹ năng sống", to: "/ky-nang-song" },
        { name: "Thiếu nhi", to: "/thieu-nhi" },
        { name: "Giáo khoa", to: "/giao-khoa" },
        { name: "Ngoại ngữ", to: "/ngoai-ngu" },
    ]

    const customerSupport = [
        { name: "Hướng dẫn mua hàng", to: "/huong-dan-mua-hang" },
        { name: "Chính sách đổi trả", to: "/chinh-sach-doi-tra" },
        { name: "Chính sách bảo mật", to: "/chinh-sach-bao-mat" },
        { name: "Điều khoản sử dụng", to: "/dieu-khoan-su-dung" },
        { name: "Câu hỏi thường gặp", to: "/faq" },
        { name: "Liên hệ", to: "/lien-he" },
    ]

    const aboutUs = [
        { name: "Giới thiệu", to: "/gioi-thieu" },
        { name: "Tuyển dụng", to: "/tuyen-dung" },
        { name: "Tin tức", to: "/tin-tuc" },
        { name: "Khuyến mãi", to: "/khuyen-mai" },
        { name: "Đối tác", to: "/doi-tac" },
        { name: "Cửa hàng", to: "/cua-hang" },
    ]

    return (
        <footer className="bg-gray-900 text-white">
            {/* Main Footer Content */}
            <div className="container mx-auto px-4 py-12">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {/* Company Info */}
                    <div className="space-y-4">
                        <div className="flex items-center space-x-2">
                            <div className="h-8 w-8 rounded bg-primary flex items-center justify-center">
                                <span className="text-white font-bold text-lg">📚</span>
                            </div>
                            <span className="text-xl font-bold">BookStore</span>
                        </div>
                        <p className="text-gray-300 text-sm leading-relaxed">
                            Cửa hàng sách trực tuyến hàng đầu Việt Nam với hàng triệu đầu sách từ trong nước và quốc tế. Chúng tôi cam
                            kết mang đến cho bạn những cuốn sách chất lượng với giá tốt nhất.
                        </p>

                        {/* Contact Info */}
                        <div className="space-y-2">
                            <div className="flex items-center space-x-2 text-sm text-gray-300">
                                <MapPin className="h-4 w-4" />
                                <span>123 Đường Nguyễn Văn Cừ, Q.1, TP.HCM</span>
                            </div>
                            <div className="flex items-center space-x-2 text-sm text-gray-300">
                                <Phone className="h-4 w-4" />
                                <span>1900 1234</span>
                            </div>
                            <div className="flex items-center space-x-2 text-sm text-gray-300">
                                <Mail className="h-4 w-4" />
                                <span>support@bookstore.vn</span>
                            </div>
                        </div>
                    </div>

                    {/* Book Categories */}
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Danh mục sách</h3>
                        <ul className="space-y-2">
                            {bookCategories.map((category) => (
                                <li key={category.name}>
                                    <Link to={category.to} className="text-gray-300 hover:text-white text-sm transition-colors">
                                        {category.name}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {/* Customer Support */}
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Hỗ trợ khách hàng</h3>
                        <ul className="space-y-2">
                            {customerSupport.map((item) => (
                                <li key={item.name}>
                                    <Link to={item.to} className="text-gray-300 hover:text-white text-sm transition-colors">
                                        {item.name}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {/* About Us & Newsletter */}
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Về chúng tôi</h3>
                        <ul className="space-y-2">
                            {aboutUs.map((item) => (
                                <li key={item.name}>
                                    <Link to={item.to} className="text-gray-300 hover:text-white text-sm transition-colors">
                                        {item.name}
                                    </Link>
                                </li>
                            ))}
                        </ul>

                        {/* Newsletter Signup */}
                        <div className="mt-6">
                            <h4 className="text-sm font-semibold mb-2">Đăng ký nhận tin</h4>
                            <p className="text-xs text-gray-400 mb-3">Nhận thông tin về sách mới và khuyến mãi đặc biệt</p>
                            <div className="flex space-x-2">
                                <Input
                                    type="email"
                                    placeholder="Email của bạn"
                                    className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-400 text-sm"
                                />
                                <Button size="sm" className="px-4">
                                    Đăng ký
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <Separator className="bg-gray-700" />

            {/* Bottom Footer */}
            <div className="container mx-auto px-4 py-6">
                <div className="flex flex-col lg:flex-row justify-between items-center space-y-4 lg:space-y-0">
                    {/* Social Media */}
                    <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-400">Theo dõi chúng tôi:</span>
                        <div className="flex space-x-3">
                            <Link to="#" className="text-gray-400 hover:text-white transition-colors">
                                <Facebook className="h-5 w-5" />
                                <span className="sr-only">Facebook</span>
                            </Link>
                            <Link to="#" className="text-gray-400 hover:text-white transition-colors">
                                <Instagram className="h-5 w-5" />
                                <span className="sr-only">Instagram</span>
                            </Link>
                            <Link to="#" className="text-gray-400 hover:text-white transition-colors">
                                <Twitter className="h-5 w-5" />
                                <span className="sr-only">Twitter</span>
                            </Link>
                            <Link to="#" className="text-gray-400 hover:text-white transition-colors">
                                <Youtube className="h-5 w-5" />
                                <span className="sr-only">YouTube</span>
                            </Link>
                        </div>
                    </div>

                    {/* Payment Methods */}
                    <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-400">Phương thức thanh toán:</span>
                        <div className="flex space-x-2">
                            <div className="bg-white rounded px-2 py-1">
                                <span className="text-xs font-bold text-blue-600">VISA</span>
                            </div>
                            <div className="bg-white rounded px-2 py-1">
                                <span className="text-xs font-bold text-red-600">MC</span>
                            </div>
                            <div className="bg-white rounded px-2 py-1">
                                <span className="text-xs font-bold text-blue-800">MOMO</span>
                            </div>
                            <div className="bg-white rounded px-2 py-1">
                                <span className="text-xs font-bold text-green-600">GRAB</span>
                            </div>
                        </div>
                    </div>

                    {/* Copyright */}
                    <div className="text-center lg:text-right">
                        <p className="text-sm text-gray-400">© 2024 BookStore. Tất cả quyền được bảo lưu.</p>
                        <p className="text-xs text-gray-500 mt-1">Giấy phép kinh doanh số: 0123456789</p>
                    </div>
                </div>
            </div>

            {/* Back to Top Button */}
            <div className="fixed bottom-6 right-6">
                <Button
                    size="icon"
                    className="rounded-full shadow-lg"
                    onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
                >
                    ↑<span className="sr-only">Về đầu trang</span>
                </Button>
            </div>
        </footer>
    )
}
