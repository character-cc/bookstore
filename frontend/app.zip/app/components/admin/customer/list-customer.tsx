"use client"

import { useState } from "react"
import { ChevronDown, ChevronLeft, ChevronRight, Edit, Eye, Filter, MoreHorizontal, Plus, Search, Trash2, UserCheck, UserX, Download } from 'lucide-react'

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select"
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table"

// Mock data cho users
const mockUsers = [
    {
        id: 1,
        name: "Nguyễn Văn An",
        email: "nguyenvanan@email.com",
        phone: "0901234567",
        status: "active",
        role: "customer",
        joinDate: "2024-01-15",
        lastLogin: "2024-01-28",
        totalOrders: 12,
        totalSpent: 2450000,
        avatar: "/placeholder.svg?height=32&width=32"
    },
    {
        id: 2,
        name: "Trần Thị Bình",
        email: "tranthibinh@email.com",
        phone: "0912345678",
        status: "inactive",
        role: "customer",
        joinDate: "2024-01-10",
        lastLogin: "2024-01-20",
        totalOrders: 5,
        totalSpent: 890000,
        avatar: "/placeholder.svg?height=32&width=32"
    },
    {
        id: 3,
        name: "Lê Minh Cường",
        email: "leminhcuong@email.com",
        phone: "0923456789",
        status: "active",
        role: "admin",
        joinDate: "2023-12-01",
        lastLogin: "2024-01-28",
        totalOrders: 0,
        totalSpent: 0,
        avatar: "/placeholder.svg?height=32&width=32"
    },
    {
        id: 4,
        name: "Phạm Thị Dung",
        email: "phamthidung@email.com",
        phone: "0934567890",
        status: "suspended",
        role: "customer",
        joinDate: "2024-01-05",
        lastLogin: "2024-01-25",
        totalOrders: 8,
        totalSpent: 1200000,
        avatar: "/placeholder.svg?height=32&width=32"
    },
    {
        id: 5,
        name: "Hoàng Văn Em",
        email: "hoangvanem@email.com",
        phone: "0945678901",
        status: "active",
        role: "customer",
        joinDate: "2024-01-20",
        lastLogin: "2024-01-28",
        totalOrders: 3,
        totalSpent: 650000,
        avatar: "/placeholder.svg?height=32&width=32"
    },
]

export default function AdminUserTable() {
    const [nameSearch, setNameSearch] = useState("")
    const [emailSearch, setEmailSearch] = useState("")
    const [phoneSearch, setPhoneSearch] = useState("")
    const [users, setUsers] = useState(mockUsers)
    const [statusFilter, setStatusFilter] = useState("all")
    const [roleFilter, setRoleFilter] = useState("all")
    const [currentPage, setCurrentPage] = useState(1)
    const [itemsPerPage, setItemsPerPage] = useState(10)
    const [selectedUsers, setSelectedUsers] = useState<number[]>([])
    const [sortField, setSortField] = useState<string>("")
    const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc")

    // Filter và search logic
    const filteredUsers = users.filter(user => {
        const matchesName = nameSearch === "" || user.name.toLowerCase().includes(nameSearch.toLowerCase())
        const matchesEmail = emailSearch === "" || user.email.toLowerCase().includes(emailSearch.toLowerCase())
        const matchesPhone = phoneSearch === "" || user.phone.includes(phoneSearch)

        const matchesStatus = statusFilter === "all" || user.status === statusFilter
        const matchesRole = roleFilter === "all" || user.role === roleFilter

        return matchesName && matchesEmail && matchesPhone && matchesStatus && matchesRole
    })

    // Sorting logic
    const sortedUsers = [...filteredUsers].sort((a, b) => {
        if (!sortField) return 0

        let aValue = a[sortField as keyof typeof a]
        let bValue = b[sortField as keyof typeof b]

        if (typeof aValue === 'string') {
            aValue = aValue.toLowerCase()
            bValue = (bValue as string).toLowerCase()
        }

        if (sortDirection === "asc") {
            return aValue < bValue ? -1 : aValue > bValue ? 1 : 0
        } else {
            return aValue > bValue ? -1 : aValue < bValue ? 1 : 0
        }
    })

    // Pagination logic
    const totalPages = Math.ceil(sortedUsers.length / itemsPerPage)
    const startIndex = (currentPage - 1) * itemsPerPage
    const paginatedUsers = sortedUsers.slice(startIndex, startIndex + itemsPerPage)

    // Handle sorting
    const handleSort = (field: string) => {
        if (sortField === field) {
            setSortDirection(sortDirection === "asc" ? "desc" : "asc")
        } else {
            setSortField(field)
            setSortDirection("asc")
        }
    }

    // Handle select all
    const handleSelectAll = (checked: boolean) => {
        if (checked) {
            setSelectedUsers(paginatedUsers.map(user => user.id))
        } else {
            setSelectedUsers([])
        }
    }

    // Handle individual select
    const handleSelectUser = (userId: number, checked: boolean) => {
        if (checked) {
            setSelectedUsers([...selectedUsers, userId])
        } else {
            setSelectedUsers(selectedUsers.filter(id => id !== userId))
        }
    }

    // Status badge component
    const StatusBadge = ({ status }: { status: string }) => {
        const variants = {
            active: "bg-green-100 text-green-800",
            inactive: "bg-gray-100 text-gray-800",
            suspended: "bg-red-100 text-red-800"
        }

        const labels = {
            active: "Hoạt động",
            inactive: "Không hoạt động",
            suspended: "Tạm khóa"
        }

        return (
            <Badge className={variants[status as keyof typeof variants]}>
                {labels[status as keyof typeof labels]}
            </Badge>
        )
    }

    // Role badge component
    const RoleBadge = ({ role }: { role: string }) => {
        const variants = {
            admin: "bg-purple-100 text-purple-800",
            customer: "bg-blue-100 text-blue-800"
        }

        const labels = {
            admin: "Quản trị viên",
            customer: "Khách hàng"
        }

        return (
            <Badge className={variants[role as keyof typeof variants]}>
                {labels[role as keyof typeof labels]}
            </Badge>
        )
    }

    // Format currency
    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(amount)
    }

    return (
        <Card className="w-full">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle>Quản lý người dùng</CardTitle>
                        <CardDescription>
                            Quản lý thông tin và trạng thái của tất cả người dùng trong hệ thống
                        </CardDescription>
                    </div>
                    <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-2" />
                            Xuất Excel
                        </Button>
                        <Button size="sm">
                            <Plus className="h-4 w-4 mr-2" />
                            Thêm người dùng
                        </Button>
                    </div>
                </div>
            </CardHeader>

            <CardContent>
                {/* Filters and Search */}
                <div className="flex flex-col gap-4 mb-6">
                    {/* Search Fields Row */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                            <Input
                                placeholder="Tìm kiếm theo tên..."
                                value={nameSearch}
                                onChange={(e) => setNameSearch(e.target.value)}
                                className="pl-10"
                            />
                        </div>

                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                            <Input
                                placeholder="Tìm kiếm theo email..."
                                value={emailSearch}
                                onChange={(e) => setEmailSearch(e.target.value)}
                                className="pl-10"
                            />
                        </div>

                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                            <Input
                                placeholder="Tìm kiếm theo số điện thoại..."
                                value={phoneSearch}
                                onChange={(e) => setPhoneSearch(e.target.value)}
                                className="pl-10"
                            />
                        </div>
                    </div>

                    {/* Filters Row */}
                    <div className="flex gap-2">
                        <Select value={statusFilter} onValueChange={setStatusFilter}>
                            <SelectTrigger className="w-[140px]">
                                <SelectValue placeholder="Trạng thái" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">Tất cả</SelectItem>
                                <SelectItem value="active">Hoạt động</SelectItem>
                                <SelectItem value="inactive">Không hoạt động</SelectItem>
                                <SelectItem value="suspended">Tạm khóa</SelectItem>
                            </SelectContent>
                        </Select>

                        <Select value={roleFilter} onValueChange={setRoleFilter}>
                            <SelectTrigger className="w-[140px]">
                                <SelectValue placeholder="Vai trò" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">Tất cả</SelectItem>
                                <SelectItem value="customer">Khách hàng</SelectItem>
                                <SelectItem value="admin">Quản trị viên</SelectItem>
                            </SelectContent>
                        </Select>

                        {/* Clear Filters Button */}
                        <Button
                            variant="outline"
                            onClick={() => {
                                setNameSearch("")
                                setEmailSearch("")
                                setPhoneSearch("")
                                setStatusFilter("all")
                                setRoleFilter("all")
                            }}
                        >
                            Xóa bộ lọc
                        </Button>
                    </div>
                </div>

                {/* Bulk Actions */}
                {selectedUsers.length > 0 && (
                    <div className="flex items-center gap-2 mb-4 p-3 bg-blue-50 rounded-lg">
            <span className="text-sm text-blue-700">
              Đã chọn {selectedUsers.length} người dùng
            </span>
                        <Button variant="outline" size="sm">
                            <UserCheck className="h-4 w-4 mr-2" />
                            Kích hoạt
                        </Button>
                        <Button variant="outline" size="sm">
                            <UserX className="h-4 w-4 mr-2" />
                            Tạm khóa
                        </Button>
                        <Button variant="outline" size="sm">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Xóa
                        </Button>
                    </div>
                )}

                {/* Table */}
                <div className="rounded-md border">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-12">
                                    <Checkbox
                                        checked={selectedUsers.length === paginatedUsers.length && paginatedUsers.length > 0}
                                        onCheckedChange={handleSelectAll}
                                    />
                                </TableHead>
                                <TableHead
                                    className="cursor-pointer hover:bg-gray-50"
                                    onClick={() => handleSort('name')}
                                >
                                    Người dùng
                                    {sortField === 'name' && (
                                        <ChevronDown className={`inline h-4 w-4 ml-1 ${sortDirection === 'desc' ? 'rotate-180' : ''}`} />
                                    )}
                                </TableHead>
                                <TableHead>Liên hệ</TableHead>
                                <TableHead
                                    className="cursor-pointer hover:bg-gray-50"
                                    onClick={() => handleSort('status')}
                                >
                                    Trạng thái
                                </TableHead>
                                <TableHead>Vai trò</TableHead>
                                <TableHead
                                    className="cursor-pointer hover:bg-gray-50"
                                    onClick={() => handleSort('joinDate')}
                                >
                                    Ngày tham gia
                                </TableHead>
                                <TableHead>Đơn hàng</TableHead>
                                <TableHead>Tổng chi tiêu</TableHead>
                                <TableHead className="w-12"></TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {paginatedUsers.map((user) => (
                                <TableRow key={user.id}>
                                    <TableCell>
                                        <Checkbox
                                            checked={selectedUsers.includes(user.id)}
                                            onCheckedChange={(checked) => handleSelectUser(user.id, checked as boolean)}
                                        />
                                    </TableCell>
                                    <TableCell>
                                        <div className="flex items-center space-x-3">
                                            <img
                                                src={user.avatar || "/placeholder.svg"}
                                                alt={user.name}
                                                className="h-8 w-8 rounded-full"
                                            />
                                            <div>
                                                <div className="font-medium">{user.name}</div>
                                                <div className="text-sm text-gray-500">ID: {user.id}</div>
                                            </div>
                                        </div>
                                    </TableCell>
                                    <TableCell>
                                        <div>
                                            <div className="text-sm">{user.email}</div>
                                            <div className="text-sm text-gray-500">{user.phone}</div>
                                        </div>
                                    </TableCell>
                                    <TableCell>
                                        <StatusBadge status={user.status} />
                                    </TableCell>
                                    <TableCell>
                                        <RoleBadge role={user.role} />
                                    </TableCell>
                                    <TableCell>
                                        <div>
                                            <div className="text-sm">{user.joinDate}</div>
                                            <div className="text-xs text-gray-500">
                                                Đăng nhập: {user.lastLogin}
                                            </div>
                                        </div>
                                    </TableCell>
                                    <TableCell>
                                        <div className="text-center">
                                            <div className="font-medium">{user.totalOrders}</div>
                                            <div className="text-xs text-gray-500">đơn hàng</div>
                                        </div>
                                    </TableCell>
                                    <TableCell>
                                        <div className="font-medium">
                                            {formatCurrency(user.totalSpent)}
                                        </div>
                                    </TableCell>
                                    <TableCell>
                                        <DropdownMenu>
                                            <DropdownMenuTrigger asChild>
                                                <Button variant="ghost" size="icon">
                                                    <MoreHorizontal className="h-4 w-4" />
                                                </Button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent align="end">
                                                <DropdownMenuLabel>Hành động</DropdownMenuLabel>
                                                <DropdownMenuItem>
                                                    <Eye className="h-4 w-4 mr-2" />
                                                    Xem chi tiết
                                                </DropdownMenuItem>
                                                <DropdownMenuItem>
                                                    <Edit className="h-4 w-4 mr-2" />
                                                    Chỉnh sửa
                                                </DropdownMenuItem>
                                                <DropdownMenuSeparator />
                                                <DropdownMenuItem>
                                                    <UserCheck className="h-4 w-4 mr-2" />
                                                    Kích hoạt
                                                </DropdownMenuItem>
                                                <DropdownMenuItem>
                                                    <UserX className="h-4 w-4 mr-2" />
                                                    Tạm khóa
                                                </DropdownMenuItem>
                                                <DropdownMenuSeparator />
                                                <DropdownMenuItem className="text-red-600">
                                                    <Trash2 className="h-4 w-4 mr-2" />
                                                    Xóa
                                                </DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>

                {/* Pagination */}
                <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center space-x-2">
                        <Label htmlFor="itemsPerPage" className="text-sm">
                            Hiển thị:
                        </Label>
                        <Select value={itemsPerPage.toString()} onValueChange={(value) => setItemsPerPage(Number(value))}>
                            <SelectTrigger className="w-20">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="5">5</SelectItem>
                                <SelectItem value="10">10</SelectItem>
                                <SelectItem value="20">20</SelectItem>
                                <SelectItem value="50">50</SelectItem>
                            </SelectContent>
                        </Select>
                        <span className="text-sm text-gray-500">
              trên tổng số {filteredUsers.length} kết quả
            </span>
                    </div>

                    <div className="flex items-center space-x-2">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                            disabled={currentPage === 1}
                        >
                            <ChevronLeft className="h-4 w-4" />
                            Trước
                        </Button>

                        <div className="flex items-center space-x-1">
                            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                                const page = i + 1
                                return (
                                    <Button
                                        key={page}
                                        variant={currentPage === page ? "default" : "outline"}
                                        size="sm"
                                        onClick={() => setCurrentPage(page)}
                                        className="w-8 h-8 p-0"
                                    >
                                        {page}
                                    </Button>
                                )
                            })}
                        </div>

                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                            disabled={currentPage === totalPages}
                        >
                            Sau
                            <ChevronRight className="h-4 w-4" />
                        </Button>
                    </div>
                </div>
            </CardContent>
        </Card>
    )
}
